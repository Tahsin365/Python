import random
import os

# Function to load words based on difficulty level
def load_words(level):
    try:
        with open('word.txt', 'r') as file:
            all_words = file.read().splitlines()  # Read all lines and split into a list
    except FileNotFoundError:
        print("The word file was not found.")
        return []

    # Categorize words based on difficulty level
    if level == 'easy':
        return [word for word in all_words if len(word) <= 3]  # Easy words (3 letters or less)
    elif level == 'medium':
        return [word for word in all_words if 4 <= len(word) <= 6]  # Medium words (4 to 6 letters)
    elif level == 'hard':
        return [word for word in all_words if len(word) > 6]  # Hard words (more than 6 letters)
    else:
        return []

# Function to load users from the file
def load_users():
    if not os.path.exists('info.txt'):
        return {}
    with open('info.txt', 'r') as file:
        users = {}
        for line in file:
            username, password = line.strip().split(',')
            users[username] = {'password': password, 'scores': []}
        return users

# Function to save users and their scores to the file
def save_users(users):
    with open('info.txt', 'w') as file:
        for username, data in users.items():
            file.write(f"{username},{data['password']}\n")

# Function to register a new user
def register():
    pname = input("Enter a Player Name: ")
    passw = input("Enter a Password: ")

    users = load_users()

    if pname in users:
        print("Username already exists! Please try again.")
        return None

    users[pname] = {'password': passw, 'scores': []}
    save_users(users)
    print("Registration Successful!")
    return pname

# Function to log in a user
def login():
    pname = input("Enter your player name: ")
    ppass = input("Enter your password: ")

    users = load_users()

    if pname in users and users[pname]['password'] == ppass:
        print("Login Successful!")
        return pname
    else:
        print("Wrong username or password!")
        return None

# Function to save the highest score to a file (high_scores.txt)
def save_high_score(username, score):
    with open('high_scores.txt', 'a') as file:
        file.write(f'{username}: {score}\n')

# Function to display the high scores from high_scores.txt
def display_high_scores():
    try:
        with open('high_scores.txt', 'r') as file:
            high_scores = file.readlines()
            if high_scores:
                print("\nHigh Scores:")
                for line in high_scores:
                    print(line.strip())
            else:
                print("No high scores yet.")
    except FileNotFoundError:
        print("No high scores found.")
        
# Function to start the game
def start_game(username):
    score = 0
    level = 'easy'

    while True:
        words = load_words(level)
        if not words:
            print("No words available for the current level.")
            break
        
        word = random.choice(words)
        jumbled_word = ''.join(random.sample(word, len(word)))
        
        print(f"\nJumbled word: {jumbled_word}")
        guess = input("Your guess: ")
        
        if guess.lower() == word:
            score += 5
            print("Correct! You've earned 5 points.")
        else:
            print(f"Wrong! The correct word was '{word}'.")
        
        print(f"Your current score: {score}")
        
        # Level up logic
        if score >= 25:
            level = 'hard'
            print("Congratulations! You've reached the hard level.")
        elif score >= 15:
            level = 'medium'
            print("Congratulations! You've reached the medium level.")
        
        # Check if the player wants to continue
        continue_game = input("Do you want to continue playing? (y/n): ").strip().lower()
        if continue_game != 'y':
            break
    
    print(f"Game over! Your final score: {score}")
    
    # Save the high score
    save_high_score(username, score)

def main():
    while True:
        print("Welcome To Word Jumble Game!")
        print("Prepared By Hojaifa Hossain, Md Labib, Md Shadman Tahsin Khan.")
        print("===============================================================")
        print("1. Register")
        print("2. Login")
        print("3. Exit")
        print("========================================")
        option = input("Choose an option: ")

        if option == '1':
            username = register()
            if username:
                print(f"Welcome, {username}!")
                # Automatically log the user in after registration
                logged_in_user = login()
                if logged_in_user:
                    print(f"Hello, {logged_in_user}!")
                    while True:
                        print("\n1. View High Scores")
                        print("2. Start Game")
                        print("3. Log Out")
                        action = input("Choose an option: ")

                        if action == '1':
                            display_high_scores()
                        elif action == '2':
                            start_game(logged_in_user)
                        elif action == '3':
                            print("Logging out...")
                            break
                        else:
                            print("Invalid option! Please try again.")
        elif option == '2':
            username = login()
            if username:
                print(f"Welcome back, {username}!")
                while True:
                    print("\n1. View High Scores")
                    print("2. Start Game")
                    print("3. Log Out")
                    action = input("Choose an option: ")

                    if action == '1':
                        display_high_scores()
                    elif action == '2':
                        start_game(username)
                    elif action == '3':
                        print("Logging out...")
                        break
                    else:
                        print("Invalid option! Please try again.")
        elif option == '3':
            print("Goodbye!")
            break
        else:
            print("Please choose a valid option!")
            print("========================================")

if __name__ == "__main__":
    main()
